const Footer = () => {
    return(
        <>
<footer className="footer">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3162.111677235935!2d126.97473421573828!3d37.575987879796195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357ca2eaa19c763d%3A0xb28a32722d675764!2z6rSR7ZmU66y4KEd3YW5naHdhbXVuIEdhdGUp!5e0!3m2!1sko!2skr!4v1481946656451"frameborder="0" allowfullscreen></iframe>
    <p className="copyright">&copy; SJW</p>
</footer>
        </>
    )
}
export default Footer;