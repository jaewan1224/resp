const Body = () => {
    return(
        <>
        <article className="slider">
            <img src="images/p-images/slide01.jpg" alt=""/>
        </article>
        <section className="content">

            <section className="display-section">
                <div className="container">
                    <h2 className="sec-tit">WE ARE</h2>
                    <p className="desc">                    
                    Pariatur mollit sunt aliquip ex eu. Fugiat enim elit ea do excepteur fugiat ea esse labore consectetur id.<br/> Ipsum sint dolore ad dolor adipisicing culpa est veniam aute nostrud in cillum proident.
                    </p>
                </div>    
            </section>

            <section className="promotion-section">
                <div className="container">
                    <ul class="promo-list">
                        <li>
                            <a href="#">
                                <img src="images/s-images/promo01.png" alt=""/>
                                <h3>HOME</h3>
                                <p>Ad aliquip nulla quis consectetur ex non minim et ut dolor sit ipsum ea.</p>
                            </a>
                        </li>
                        
                        <li>
                            <a href="#">
                                <img src="images/s-images/promo02.png" alt=""/>
                                <h3>WE ARE</h3>
                                <p>Ad aliquip nulla quis consectetur ex non minim et ut dolor sit ipsum ea.</p>
                            </a>
                        </li>
                        
                        <li>
                            <a href="#">
                                <img src="images/s-images/promo03.png" alt=""/>
                                <h3>WORK</h3>
                                <p>Ad aliquip nulla quis consectetur ex non minim et ut dolor sit ipsum ea.</p>
                            </a>
                        </li>
                        
                        <li>
                            <a href="#">
                                <img src="images/s-images/promo04.png" alt=""/>
                                <h3>BLOG</h3>
                                <p>Ad aliquip nulla quis consectetur ex non minim et ut dolor sit ipsum ea.</p>
                            </a>
                        </li>


                    </ul>
                </div>
            </section>

            <hr className="divider"/>

        </section>
        </>
    )
}
export default Body;
